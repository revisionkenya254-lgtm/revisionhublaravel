<div class="dashboard__sidebar-wrap">
    <div class="dashboard__sidebar-title mb-20">
        <h6 class="title">{{ __('Welcome') }}, {{ userAuth()->name }}</h6>
    </div>
    @use('Nwidart\Modules\Facades\Module')
    <nav class="dashboard__sidebar-menu">
        <ul class="list-wrap">
            <li class="{{ Route::is('student.dashboard') ? 'active' : '' }}">
                <a href="{{ route('student.dashboard') }}">
                    <img src="{{asset('uploads/website-images/dashboard.svg')}}">
                    {{ __('Dashboard') }}
                </a>
            </li>

            <li class="{{ Route::is('student.orders.index') ? 'active' : '' }}">
                <a href="{{ route('student.orders.index') }}">
                    <img src="{{asset('uploads/website-images/order-history.svg')}}">
                    {{ __('Order History') }}
                </a>
            </li>
            <li class="{{ Route::is('refund-request.index') ? 'active' : '' }}">
                <a href="{{ route('refund-request.index') }}">
                    <img src="{{asset('uploads/website-images/refund.svg')}}">
                    {{ __('Refund History') }}
                </a>
            </li>

            <li class="{{ Route::is('student.enrolled-courses') ? 'active' : '' }}">
                <a href="{{ route('student.enrolled-courses') }}">
                    <i class="flaticon-mortarboard"></i>{{ __('Enrolled Courses') }}</a>
            </li>
            <li class="{{ Route::is('student.library') ? 'active' : '' }}">
                <a href="{{ route('student.library') }}">
                    <i class="flaticon-book"></i>{{ __('Library') }}</a>
            </li>
            <li class="{{ Route::is('student.wishlist') ? 'active' : '' }}">
                <a href="{{ route('student.wishlist') }}">
                    <img src="{{asset('uploads/website-images/heart.svg')}}">{{ __('Wishlist') }}</a>
            </li>
            <li class="{{ Route::is('student.reviews.index') ? 'active' : '' }}">
                <a href="{{ route('student.reviews.index') }}">
                    <img src="{{asset('uploads/website-images/reviews.svg')}}">{{ __('Reviews') }}</a>
            </li>
            <li class="{{ Route::is('student.quiz-attempts') ? 'active' : '' }}">
                <a href="{{ route('student.quiz-attempts') }}">
                    <img src="{{asset('uploads/website-images/quiz.svg')}}">{{ __('My Quiz Attempts') }}</a>
            </li>
            <li class="{{ Route::is('student.ai-chat.*') ? 'active' : '' }}">
                <a href="{{ route('student.ai-chat.index') }}">
                    <i class="fas fa-comments"></i>{{ __('AI Chat') }}</a>
            </li>
        </ul>
    </nav>
    <div class="dashboard__sidebar-title mt-30 mb-20">
        <h6 class="title">{{ __('User') }}</h6>
    </div>
    <nav class="dashboard__sidebar-menu">
        <ul class="list-wrap">
            @if (Module::has('LiveChat') && Module::isEnabled('LiveChat') && $setting?->pusher_status == 'active')
                <li class="{{ Route::is('student.live-chat.*') ? 'active' : '' }}">
                    <a href="{{ route('student.live-chat.index') }}">
                        <img src="{{ asset('uploads/website-images/live-chat.svg') }}">
                        {{ __('Live Chat') }}
                    </a>
                </li>
            @endif
            <li class="{{ Route::is('student.devices.index') ? 'active' : '' }}">
                <a href="{{ route('student.devices.index') }}">
                    <img src="{{asset('uploads/website-images/device.svg')}}">
                    {{ __('Active Devices') }}
                </a>
            </li>
            <li class="{{ Route::is('student.setting.index') ? 'active' : '' }}">
                <a href="{{ route('student.setting.index') }}">
                    <i class="flaticon-user"></i>
                    {{ __('Profile Settings') }}
                </a>
            </li>
            @if (userAuth()?->instructorInfo)
                @php
                    $instructorStatusRoute = isInstructorAccount() ? 'instructor.dashboard' : 'become-instructor.review';
                @endphp
                <li class="{{ Route::is('become-instructor.review', 'instructor.dashboard') ? 'active' : '' }}">
                    <a href="{{ route($instructorStatusRoute) }}">
                        <i class="flaticon-user"></i>
                        {{ __('Instructor status') }}
                    </a>
                </li>
            @endif
            <li>
                <a href="{{ route('logout') }}"
                    onclick="event.preventDefault(); $('#student-logout-form').trigger('submit');">
                    <img src="{{asset('uploads/website-images/logout.svg')}}">
                    {{ __('Logout') }}
                </a>
            </li>
        </ul>
    </nav>
</div>

{{-- start student logout form --}}
<form id="student-logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
    @csrf
</form>
{{-- end student logout form --}}
